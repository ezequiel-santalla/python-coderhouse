from setuptools import setup, find_packages

setup(
  name="primer_paquete",
  version="1.0",
  description="Descripción de tu paquete",
  author="Ezequiel",
  author_email="ezequielasantalla@gmail.com",
  packages=find_packages()
)
